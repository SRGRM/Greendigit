"""Run a Task B scheduler of the challenge phase against the FCFS reference.

Standalone runner of the challenge phase (``evaluate_custom_b.py`` and its
earlier version ``evaluate_custom_b_org.py``): checks the input files,
replays the job trace in the official simulator with the FCFS reference and
with the chosen scheduler, scores the run with the official evaluator and
writes the submission artefacts (dispatch log and score metrics).

Forecast source: the offline CSV of the starter kit by default
(``data/forecast_baseline.csv``, measured signals) or any Task A forecast
CSV with the same columns.

Usage (from the repository root):

    python challenge_code/task_b/run_scheduler.py                       # 24 h smoke window
    python challenge_code/task_b/run_scheduler.py --scheduler smart
    python challenge_code/task_b/run_scheduler.py --start 2026-02-18T14:15:00 --end 2026-03-12T17:00:00
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import logging
import sys
from datetime import datetime, timezone
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]

# =============================================================================
# CONFIG
# =============================================================================
CONFIG = {
    "data_dir": REPO_ROOT / "data",                # job_trace.csv and site_config.json
    "forecast_csv": REPO_ROOT / "data" / "forecast_baseline.csv",   # offline forecast source
    "scheduler": "pareto",                         # "pareto" | "smart" | "greedy_carbon" | "fcfs"
    "objective": "carbon",                         # "carbon" | "energy" | "makespan"
    "start": "2025-11-19T23:00:00",                # smoke window of the starter kit
    "end": "2025-11-20T23:00:00",                  # full trace: "2026-03-12T17:00:00"
    "output_dir": REPO_ROOT / "runs" / "challenge_task_b",
    # Pareto scheduler parameters (challenge-phase values)
    "pareto": {"max_hold_hours": 12.0, "saving_threshold": 0.01, "makespan_penalty_weight": 0.03},
    # Smart scheduler parameters
    "smart": {"max_hold_hours": 24.0},
    "log_level": "WARNING",                        # "INFO" prints every hold decision
}

# =============================================================================

import pandas as pd  # noqa: E402

if importlib.util.find_spec("dirac_sim") is None:   # not pip-installed: use the bundled copy
    sys.path.insert(0, str(REPO_ROOT / "task-b"))

from dirac_sim.api.forecast_client import ForecastClient  # noqa: E402
from dirac_sim.baselines.fcfs import FCFSScheduler  # noqa: E402
from dirac_sim.baselines.greedy_carbon import GreedyCarbonScheduler  # noqa: E402
from dirac_sim.core.evaluator import Evaluator  # noqa: E402
from dirac_sim.core.job_queue import JobQueue  # noqa: E402
from dirac_sim.core.site_model import SiteRegistry  # noqa: E402
from dirac_sim.core.wms import WMSSimulator  # noqa: E402

sys.path.insert(0, str(Path(__file__).resolve().parent))
from pareto_scheduler import ParetoSmartScheduler  # noqa: E402
from smart_scheduler import SmartScheduler  # noqa: E402


def pre_flight_checks(paths: dict) -> None:
    """Stop before simulating if an input file is missing."""
    print("=" * 57)
    print(" Pre-flight checks")
    print("=" * 57)
    for name, path in paths.items():
        if not Path(path).is_file():
            print(f"[error] {name} not found at {path}")
            if name == "job trace":
                print("        run `python data/prepare_data.py` from the repository root")
            sys.exit(1)
        print(f"[ok] {name}: {path}")


def relative(path: Path) -> str:
    """Path relative to the repository root when it lies inside it."""
    try:
        return str(Path(path).resolve().relative_to(REPO_ROOT))
    except ValueError:
        return str(path)


def parse_utc(value: str) -> datetime:
    dt = datetime.fromisoformat(value)
    return dt.replace(tzinfo=timezone.utc) if dt.tzinfo is None else dt.astimezone(timezone.utc)


def window_trace(trace_path: Path, start: datetime, end: datetime, out_path: Path) -> Path:
    """Keep the jobs that arrive inside the window; jobs from before the
    start would be released at the first tick with an expired deadline."""
    trace = pd.read_csv(trace_path)
    arrival = pd.to_datetime(trace["arrival_time"], utc=True)
    selected = trace[(arrival >= pd.Timestamp(start)) & (arrival <= pd.Timestamp(end))]
    out_path.parent.mkdir(parents=True, exist_ok=True)
    selected.to_csv(out_path, index=False)
    print(f"[data] {len(selected):,} of {len(trace):,} jobs arrive in the window")
    return out_path


def make_scheduler(config: dict):
    name = config["scheduler"]
    if name == "pareto":
        return ParetoSmartScheduler(declared_objective=config["objective"], **config["pareto"])
    if name == "smart":
        return SmartScheduler(declared_objective=config["objective"], **config["smart"])
    if name == "greedy_carbon":
        return GreedyCarbonScheduler(declared_objective=config["objective"])
    if name == "fcfs":
        return FCFSScheduler()
    raise ValueError(f"unknown scheduler '{name}'")


def run(config: dict) -> None:
    data_dir = Path(config["data_dir"])
    paths = {"job trace": data_dir / "job_trace.csv", "site config": data_dir / "site_config.json",
             "forecast csv": Path(config["forecast_csv"])}
    pre_flight_checks(paths)
    logging.basicConfig(level=getattr(logging, config["log_level"]), format="%(levelname)s - %(message)s")

    start, end = parse_utc(config["start"]), parse_utc(config["end"])
    out_dir = Path(config["output_dir"])
    trace = window_trace(paths["job trace"], start, end, out_dir / "window_job_trace.csv")
    registry = SiteRegistry.from_json(paths["site config"])
    client = ForecastClient(offline_csv=str(paths["forecast csv"]),
                            series_ids=[s.site_id for s in registry.all_sites()])

    def simulate(scheduler):
        return WMSSimulator(queue=JobQueue.from_csv(trace), registry=SiteRegistry.from_json(paths["site config"]),
                            scheduler=scheduler, forecast_client=client, start_time=start,
                            end_time=end).run()

    print(f"\n[1/3] FCFS reference, {start.isoformat()} .. {end.isoformat()}")
    baseline = simulate(FCFSScheduler())
    print(f"[2/3] {config['scheduler']} scheduler")
    report = simulate(make_scheduler(config))
    print("[3/3] scoring")
    result = Evaluator.score(submission=report, baseline=baseline, declared_objective=config["objective"])
    print("\n" + str(result))

    baseline.to_csv(str(out_dir / "baseline_execution_report.csv"))
    report.to_csv(str(out_dir / "execution_report.csv"))
    report.to_dispatch_csv(str(out_dir / "dispatch_log.csv"), declared_objective=config["objective"])
    (out_dir / "score_summary.txt").write_text(str(result))
    with (out_dir / "score_metrics.json").open("w") as fh:
        json.dump({"run": {"scheduler": config["scheduler"], "objective": config["objective"],
                           "forecast_csv": relative(paths["forecast csv"]), "start": start.isoformat(),
                           "end": end.isoformat()},
                   "evaluation": result.to_dict()}, fh, indent=2)
    print(f"\noutputs saved to {out_dir}: dispatch_log.csv, score_metrics.json, score_summary.txt")


def main() -> None:
    parser = argparse.ArgumentParser(description="Task B scheduler runner (challenge phase)")
    parser.add_argument("--scheduler", choices=("pareto", "smart", "greedy_carbon", "fcfs"))
    parser.add_argument("--objective", choices=("carbon", "energy", "makespan"))
    parser.add_argument("--start")
    parser.add_argument("--end")
    parser.add_argument("--forecast-csv", type=Path)
    parser.add_argument("--output-dir", type=Path)
    args = parser.parse_args()
    config = dict(CONFIG)
    for key in ("scheduler", "objective", "start", "end", "forecast_csv", "output_dir"):
        value = getattr(args, key)
        if value is not None:
            config[key] = value
    run(config)


if __name__ == "__main__":
    main()
