"""Pareto trade-off scheduler of the challenge phase (Task B).

For every ready job (least deadline slack first) the scheduler compares the
signal of dispatching now with every forecast bucket inside the hold window
(12 h). A bucket is a candidate when it saves more than ``saving_threshold``
of the current signal and the job still finishes before its deadline there;
its trade-off score is the relative saving minus
``makespan_penalty_weight`` per hour of delay. The candidate with the best
positive score is chosen, otherwise the job is dispatched now. The signal is
carbon (``cfp_g_pred``) for the carbon objective and energy otherwise.

The forecast timeline is rebuilt from every bundle the simulator delivers,
so the candidates are the buckets present in the current bundle.

Change to the challenge-phase version: it also added one occupied slot to
the site for every immediate decision. The simulator already counts
dispatched jobs (and releases them once), so that line leaked one slot per
job and could block a site on long simulations; it is removed here.
"""

from __future__ import annotations

import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple

from dirac_sim.core.job_queue import Job, JobQueue
from dirac_sim.core.scheduler import (DispatchDecision, DispatchPlan, ForecastBundle, Objective,
                                      Scheduler)
from dirac_sim.core.site_model import SiteRegistry

logger = logging.getLogger("ParetoScheduler")
UNKNOWN_SIGNAL = 999999.0


class ParetoSmartScheduler(Scheduler):
    """Balances the saving of the declared signal against the delay."""

    def __init__(self, declared_objective: str = "carbon", max_hold_hours: float = 12.0,
                 saving_threshold: float = 0.01, makespan_penalty_weight: float = 0.03) -> None:
        objective = Objective(declared_objective) if isinstance(declared_objective, str) else declared_objective
        super().__init__(declared_objective=objective)
        self.max_hold_hours = max_hold_hours
        self.saving_threshold = saving_threshold
        self.makespan_penalty_weight = makespan_penalty_weight
        self._future_signals: Dict[str, List[Tuple[datetime, float]]] = {}
        logger.info("ParetoSmartScheduler: objective %s, max hold %.1f h", self.declared_objective,
                    self.max_hold_hours)

    def on_forecast_received(self, bundle: ForecastBundle) -> None:
        """Merge the 1 h and 24 h records into one sorted timeline per site."""
        if not bundle.horizon_1h and not bundle.horizon_24h:
            return
        key = "cfp_g_pred" if self.declared_objective == Objective.CARBON else "energy_wh_pred"
        by_series: Dict[str, List[Tuple[datetime, float]]] = {}
        for rec in bundle.horizon_1h + bundle.horizon_24h:
            try:
                ts = datetime.fromisoformat(str(rec.get("forecast_timestamp_utc")).replace("Z", "+00:00"))
                by_series.setdefault(rec.get("series_id", ""), []).append(
                    (ts, float(rec.get(key, UNKNOWN_SIGNAL))))
            except (TypeError, ValueError):
                continue
        for site, entries in by_series.items():
            self._future_signals[site] = sorted(set(entries), key=lambda e: e[0])

    def schedule(self, queue: JobQueue, registry: SiteRegistry, forecast: ForecastBundle,
                 now: datetime) -> DispatchPlan:
        plan = DispatchPlan(declared_objective=self.declared_objective)
        for job in sorted(queue.ready_jobs(now), key=lambda j: j.deadline_slack_minutes(now)):
            decision = self._decide_optimal_tradeoff(job, registry, now)
            if decision:
                plan.add(decision)
        return plan

    def _decide_optimal_tradeoff(self, job: Job, registry: SiteRegistry,
                                 now: datetime) -> Optional[DispatchDecision]:
        candidates = [s for s in registry.available_sites(job.site_whitelist) if s.capacity.available_slots > 0]
        if not candidates:
            return None
        best_now_site = min(candidates, key=lambda s: self._get_signal_at(s.site_id, now))
        signal_now = self._get_signal_at(best_now_site.site_id, now)

        best_time, best_site, best_score = now, best_now_site, float("-inf")
        max_hold = timedelta(hours=self.max_hold_hours)
        for site in candidates:
            for future_ts, future_signal in self._future_signals.get(site.site_id, []):
                if future_ts <= now:
                    continue
                if future_ts > now + max_hold:
                    break
                finish = future_ts + timedelta(minutes=job.cpu_minutes + site.dispatch_latency)
                if finish > job.deadline:
                    continue
                saving = (signal_now - future_signal) / (signal_now + 1e-9)
                if saving > self.saving_threshold:
                    delay_hours = (future_ts - now).total_seconds() / 3600.0
                    score = saving - self.makespan_penalty_weight * delay_hours
                    if score > best_score and score > 0:
                        best_time, best_site, best_score = future_ts, site, score

        if best_time > now:
            logger.debug("holding job %s until %s at %s (score %.2f)", job.job_id,
                         best_time.strftime("%H:%M"), best_site.site_id, best_score)
            status = f"held (score={best_score:.2f})"
        else:
            status = "immediate"
        return DispatchDecision(job_id=job.job_id, site_id=best_site.site_id, dispatch_at=best_time,
                                rationale=f"pareto_scheduler: {status}")

    def _get_signal_at(self, site_id: str, ts: datetime) -> float:
        """Signal of the first timeline bucket at or after ``ts``."""
        timeline = self._future_signals.get(site_id, [])
        for t, value in timeline:
            if t >= ts:
                return value
        return timeline[-1][1] if timeline else UNKNOWN_SIGNAL
