"""Minimum-cost window scheduler of the challenge phase (Task B).

For every ready job (least deadline slack first) the scheduler looks at the
1-hour forecast of each whitelisted site and at the 24-hour forecast
timeline up to ``max_hold_hours`` ahead, and dispatches the job in the
bucket with the lowest forecast of the declared signal (carbon or energy)
in which it still finishes before its deadline.
"""

from __future__ import annotations

from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple

from dirac_sim.core.job_queue import Job, JobQueue
from dirac_sim.core.scheduler import (DispatchDecision, DispatchPlan, ForecastBundle, Objective,
                                      Scheduler)
from dirac_sim.core.site_model import Site, SiteRegistry

UNKNOWN_SIGNAL = 999999.0


class SmartScheduler(Scheduler):
    def __init__(self, declared_objective: str = "carbon", max_hold_hours: float = 24.0) -> None:
        objective = Objective(declared_objective) if isinstance(declared_objective, str) else declared_objective
        super().__init__(declared_objective=objective)
        self.max_hold_hours = max_hold_hours
        self._future_signals: Dict[str, List[Tuple[datetime, float]]] = {}
        self._current_signals: Dict[str, float] = {}

    def on_forecast_received(self, bundle: ForecastBundle) -> None:
        key = "cfp_g_pred" if self.declared_objective == Objective.CARBON else "energy_wh_pred"
        for rec in bundle.horizon_1h:
            self._current_signals[rec.get("series_id", "")] = float(rec.get(key, UNKNOWN_SIGNAL))
        by_series: Dict[str, List[Tuple[datetime, float]]] = {}
        for rec in bundle.horizon_24h:
            try:
                ts = datetime.fromisoformat(rec.get("forecast_timestamp_utc", "").replace("Z", "+00:00"))
            except ValueError:
                continue
            by_series.setdefault(rec.get("series_id", ""), []).append(
                (ts, float(rec.get(key, UNKNOWN_SIGNAL))))
        for site, entries in by_series.items():
            self._future_signals[site] = sorted(entries, key=lambda e: e[0])

    def schedule(self, queue: JobQueue, registry: SiteRegistry, forecast: ForecastBundle,
                 now: datetime) -> DispatchPlan:
        plan = DispatchPlan(declared_objective=self.declared_objective)
        for job in sorted(queue.ready_jobs(now), key=lambda j: j.deadline_slack_minutes(now)):
            decision = self._decide_optimal_window(job, registry, now)
            if decision:
                plan.add(decision)
        return plan

    def _decide_optimal_window(self, job: Job, registry: SiteRegistry,
                               now: datetime) -> Optional[DispatchDecision]:
        candidates = [s for s in registry.available_sites(job.site_whitelist) if s.capacity.available_slots > 0]
        if not candidates:
            return None                         # no free slot anywhere: wait for the next tick
        best_site: Optional[Site] = None
        best_time, best_value = now, float("inf")
        max_hold = timedelta(hours=self.max_hold_hours)
        for site in candidates:
            current = self._current_signals.get(site.site_id, UNKNOWN_SIGNAL)
            if current < best_value:
                best_site, best_time, best_value = site, now, current
            for ts, value in self._future_signals.get(site.site_id, []):
                if ts <= now:
                    continue
                if ts > now + max_hold:
                    break
                finish = ts + timedelta(minutes=job.cpu_minutes + site.dispatch_latency)
                if finish > job.deadline:
                    continue
                if value < best_value:
                    best_site, best_time, best_value = site, ts, value
        if best_site is None:
            return None
        status = "immediate" if best_time == now else "held"
        return DispatchDecision(job_id=job.job_id, site_id=best_site.site_id, dispatch_at=best_time,
                                rationale=f"smart_scheduler: {status} dispatch to {best_site.site_id} "
                                          f"(target_cost={best_value:.1f})")
