# Challenge-phase code

Code written during the GreenDIGIT ECML-PKDD 2026 Discovery Challenge (team
ISystems), before the Green-GRM search was formalised for the paper. The
scripts are the ones of the challenge archive, reorganised and documented;
their training and scoring logic is unchanged, apart from the points listed
under "Notes on the pipeline", so their results can be reproduced. The
numbers reported in the paper (Table 2 and the challenge score) were
obtained with this pipeline: its feature library and composite score are
also available to the Green-GRM search as the `challenge_lab` protocol
(`green_grm/greengrm/lab_protocol.py`).

| Script | Archive file | What it does |
| --- | --- | --- |
| `task_a/model_lab.py` | `super.py` | Experiment grid: 3 feature strategies x 9 architectures (6 HistGradientBoosting, 3 PyTorch MLPs). Trains on the buckets up to the cut-off, scores the public buckets after it with the composite score, saves models, submission files and the official score. |
| `task_a/feature_library.py` | `super.py` | Data loading and the feature library (lags, workload lags, rolling means, momentum, calendar) used by the lab. |
| `task_a/torch_models.py` | `super.py` | The PyTorch MLP of the lab and its scikit-learn style wrapper, with per-epoch history and checkpoints. |
| `task_a/composite_evaluator.py` | `super.py`, `unified_baseline.py` | The composite score of the challenge phase (two variants). |
| `task_a/evaluate_lab_model.py` | `unified_baseline.py` | Loads a saved lab model, writes the three Task A files and scores them read back from disk. |
| `task_a/random_forest_baseline.py` | `task-a/src/task_a/run_custom_model.py` | First model of the challenge: calendar features and random forests. |
| `task_a/evaluate_submission.py` | `task-a/src/task_a/evaluate_custom.py` | Official starter-kit score (and composite score) of any submission folder. |
| `task_b/pareto_scheduler.py` | `task-b/my_pareto_scheduler.py` | Pareto trade-off scheduler (saving vs delay, 12 h hold). |
| `task_b/smart_scheduler.py` | `task-b/my_smart_scheduler.py` | Minimum-cost window scheduler (24 h hold). |
| `task_b/run_scheduler.py` | `task-b/evaluate_custom_b.py`, `evaluate_custom_b_org.py` | Runs a scheduler and FCFS in the official simulator and writes the Task B artefacts. |
| `eda/data_diagnostics.py` | (outputs only in the archive) | Data diagnostics report and figures. The challenge-phase outputs are in `results/eda/challenge_phase/`; rerunning the script on `summary_sites_raw.csv` gives the same statistics (only the memory figure depends on the pandas version). |

All scripts start with a `CONFIG` block that lists every option with its
alternatives; they run from the repository root and stop with a message when
an input file is missing.

## Two Task A scores

* **Official starter-kit ScoreTA** (`task-a/src/task_a/evaluation.py`, Eq. 2
  of the paper): `0.7 * mean(S(A)_1h, S(A)_24h) + 0.15 * S(A.1) + 0.15 * S(A.2)`
  with sMAPE forecast terms and `S = 1 - (AUROC + F1) / 2` for the detectors.
  **Lower is better**; the starter-kit baseline scores 0.7646 locally.
* **Composite score of the challenge phase** (`composite_evaluator.py`):
  `(F1_A.1 + F1_A.2 + 0.5 / (1 + MAE_energy) + 0.5 / (1 + MAE_cfp)) / 3`.
  **Higher is better.** The challenge score reported in the paper (0.38615)
  matches this scale.

## Reproduced results (public split, cut-off 2026-02-18 14:00 UTC)

| Model | Composite score | Energy MAE | Carbon MAE | A.1 F1 | A.2 F1 | Official ScoreTA |
| --- | --- | --- | --- | --- | --- | --- |
| Starter-kit baseline | - | - | - | - | - | 0.7646 |
| Random forest (`random_forest_baseline.py`) | - | - | - | - | - | 0.7578 |
| Exp_21 Deep_Momentum_Lags + HGB absolute loss | 0.38892 | 166.17 | 164.16 | 0.9658 | 0.1950 | 0.5958 |
| Green-GRM selection (abs, eta 0.01, T 200, depth 5, L2 25) in this pipeline | 0.38900 | 167.14 | 168.98 | 0.9661 | 0.1950 | 0.6015 |

The paper reports a challenge score of 0.38615 (energy MAE 164.78, peak F1
0.184) for its selected configuration. The search run behind that number is
not part of the archive; the closest settings of this pipeline land within
0.003 of it. With scikit-learn 1.9.1 the Exp_21 numbers are identical, to
the last digit, to the output of the archived `super.py` (scikit-learn 1.2.2
gives 0.39073 from the same features), and `random_forest_baseline.py`
reproduces the official score of the archived run (0.7578).

Task B, challenge-phase Pareto scheduler with the offline signal source of
the starter kit (`data/forecast_baseline.csv`, i.e. the measured signal of the
current and the next hour):

| Window | Task B score | ΔEnergy | ΔCarbon | Deadline penalty | Jobs dispatched / jobs |
| --- | --- | --- | --- | --- | --- |
| Smoke window 2025-11-19 23:00 to 2025-11-20 23:00 | 0.3285 | +0.4082 | +0.4082 | 0.0148 | 295 / 304 |
| Test window 2026-02-18 14:15 to 2026-03-12 17:00 | 0.3189 | +0.3573 | +0.4134 | 0.0000 | 5,938 / 5,938 |

These runs see measured signals, not forecasts, so they are not comparable
with the forecast-driven results of `green_grm/run_task_b.py`.

The outputs of these runs are in `results/challenge_code/`.

## Notes on the pipeline

* Every lab model is a one-hour-ahead model: the features of a bucket use
  values at least four buckets (1 h) older. The challenge-phase submission
  wrote this forecast for both horizons; for the 24-hour horizon it therefore
  uses information that is not yet available 24 hours ahead. The Green-GRM
  implementation (`green_grm/`, protocol `paper`) trains separate 1 h and 24 h
  models instead.
* The in-loop evaluation of `model_lab.py` scores the zero-filled hold-out:
  every bucket counts as valid for A.1, and the A.2 labels use the 95th
  percentile of each site within the hold-out. `evaluate_lab_model.py` keeps
  gaps as NaN, so its A.1 labels and MAE differ slightly.
* `pareto_scheduler.py` no longer adds an occupied slot for every immediate
  decision (the simulator already counts dispatched jobs; the extra count
  leaked one slot per job and could block a site on long simulations).
* `run_scheduler.py` keeps only the jobs that arrive inside the simulated
  window. With the default smoke window at the start of the trace this
  changes nothing; for later windows it avoids releasing older jobs with an
  expired deadline at the first tick.
* PyTorch is needed only for the three MLP architectures. `gpu_ids` selects
  the GPUs (`CUDA_VISIBLE_DEVICES`, `nn.DataParallel` for more than one). The
  code uses no feature newer than PyTorch 1.8, so the same script runs on the
  CUDA 11.4 and CUDA 12.2 machines; `requirements-torch-cuda114.txt` and
  `requirements-torch-cuda122.txt` at the root of the repository install a
  matching PyTorch build for each. The MLP path was tested on the CPU with
  PyTorch 1.9.1 and Python 3.9.
* The MLP training loop is the one of `super.py`. Each network is now seeded
  (`torch_seed`), prints its progress every `print_every_epochs` epochs and,
  with `save_epoch_checkpoints`, stores its weights after every epoch. From
  these weights `model_lab.py` rebuilds the Task A files and the composite
  score of every epoch (`epoch_submissions`) and writes them, with the
  training losses, to `training_report.csv` in the experiment folder. The
  two larger MLPs take about 4 MB per network and epoch, so the full grid
  (nine MLP experiments of 100 epochs) writes about 12 GB with these
  options on.
