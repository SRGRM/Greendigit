"""Evaluate a saved model-lab model on the public hold-out ("unified" evaluator).

Challenge-phase counterpart: ``unified_baseline.py``. It loads trained
models, rebuilds exactly the features they were trained on, predicts every
bucket after the cut-off, writes the three Task A files, writes the hold-out
ground truth to CSV and scores the files read back from disk ("CSV bounce",
so the evaluator sees the same strings as an external scorer).

Differences to the in-loop evaluation of ``model_lab.py``: the ground truth
keeps gaps as NaN (missing buckets count as invalid for A.1 and are left out
of the MAE), and the composite uses the "unified" forecast term
1 / (1 + MAE_energy). The original script expected the output of an earlier
trainer (``advanced_trainer.py``, not part of the archive); here it reads
the ``models.joblib`` written by ``model_lab.py``.

Usage (from the repository root):

    python challenge_code/task_a/evaluate_lab_model.py
    python challenge_code/task_a/evaluate_lab_model.py --model runs/challenge_lab/<experiment>/models.joblib
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]

# =============================================================================
# CONFIG
# =============================================================================
CONFIG = {
    "model_path": REPO_ROOT / "runs" / "challenge_lab" / "Exp_21_Deep_Momentum_Lags_HGB_Absolute_Loss"
                  / "models.joblib",
    "data_path": REPO_ROOT / "data" / "raw_metrics" / "summary_sites_15m.csv",
    "sites": ("site_ad3433ffac", "site_e726c7cce5", "site_f5bcf8a88a"),
    "split_cutoff_utc": "2026-02-18T14:00:00+00:00",
    "output_dir": None,                 # None -> "<model folder>/unified_evaluation"
    "composite_variant": "unified",     # "unified" (this script in the challenge) | "lab" (model_lab.py)
    "official_score": True,             # also score with the starter-kit evaluator
}

# =============================================================================

import joblib  # noqa: E402
import pandas as pd  # noqa: E402

sys.path.insert(0, str(Path(__file__).resolve().parent))
import composite_evaluator  # noqa: E402
from evaluate_submission import official_task_a_score  # noqa: E402
from feature_library import DataLoadError, load_and_build_master_dataset, load_ground_truth  # noqa: E402

ISO = "%Y-%m-%dT%H:%M:%S+00:00"


def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate a saved model-lab model")
    parser.add_argument("--model", type=Path, default=None)
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--output-dir", type=Path, default=None)
    args = parser.parse_args()
    config = dict(CONFIG)
    if args.model:
        config["model_path"] = args.model
    if args.data:
        config["data_path"] = args.data
    if args.output_dir:
        config["output_dir"] = args.output_dir

    print("=" * 65)
    print(" Task A: evaluation of a saved model-lab model")
    print("=" * 65)
    model_path = Path(config["model_path"])
    if not model_path.is_file():
        print(f"[error] model file not found: {model_path} (run model_lab.py first) -- stopping.")
        sys.exit(1)
    print(f"[1/4] loading models from {model_path}")
    models = joblib.load(model_path)
    features = models.get("__FEATURE_NAMES__", [])
    if not features:
        print("[error] the model file has no '__FEATURE_NAMES__' entry -- stopping.")
        sys.exit(1)

    print("[2/4] loading the data and rebuilding the features")
    try:
        frame = load_and_build_master_dataset(config["data_path"], config["sites"], verbose=False)
        truth = load_ground_truth(config["data_path"], config["sites"])
    except DataLoadError as exc:
        print(f"[error] {exc} -- stopping.")
        sys.exit(1)
    missing = [f for f in features if f not in frame.columns]
    if missing:
        print(f"[error] the data cannot provide the model features {missing} -- stopping.")
        sys.exit(1)
    cutoff = pd.Timestamp(config["split_cutoff_utc"])
    test = frame[frame["bucket_15m"] > cutoff]
    truth = truth[truth["bucket_15m"] > cutoff]
    X_test = test[features]

    out_dir = Path(config["output_dir"]) if config["output_dir"] else model_path.parent / "unified_evaluation"
    out_dir.mkdir(parents=True, exist_ok=True)
    gt_path = out_dir / "ground_truth_test.csv"
    truth.assign(bucket_15m=truth["bucket_15m"].dt.strftime(ISO)).to_csv(gt_path, index=False)

    print(f"[3/4] predicting {len(test):,} hold-out buckets")
    stamps = test["bucket_15m"].dt.strftime(ISO).to_numpy()
    sites = test["series_id"].to_numpy()
    detections = pd.DataFrame({"series_id": sites, "bucket_15m": stamps,
                               "valid_signal_score": models["det"].predict_proba(X_test)[:, 1],
                               "valid_signal_pred": models["det"].predict(X_test).astype(int)})
    peaks = pd.DataFrame({"series_id": sites, "bucket_15m": stamps,
                          "peak_score": models["peak"].predict_proba(X_test)[:, 1],
                          "peak_pred": models["peak"].predict(X_test).astype(int)})
    energy = models["energy"].predict(X_test).clip(min=0)
    cfp = models["cfp"].predict(X_test).clip(min=0)
    forecasts = pd.concat([pd.DataFrame({"series_id": sites, "forecast_timestamp_utc": stamps,
                                         "horizon_steps_15m": h, "energy_wh_pred": energy,
                                         "cfp_g_pred": cfp}) for h in (4, 96)], ignore_index=True)
    paths = {"forecasts": out_dir / "forecast_submission.csv",
             "detections": out_dir / "detection_submission.csv",
             "peaks": out_dir / "peak_submission.csv"}
    forecasts.to_csv(paths["forecasts"], index=False)
    detections.to_csv(paths["detections"], index=False)
    peaks.to_csv(paths["peaks"], index=False)

    print("[4/4] scoring the files read back from disk")
    results = composite_evaluator.score(pd.read_csv(gt_path), pd.read_csv(paths["forecasts"]),
                                        pd.read_csv(paths["detections"]), pd.read_csv(paths["peaks"]),
                                        variant=config["composite_variant"])
    if config["official_score"]:
        official = official_task_a_score(config["data_path"], config["split_cutoff_utc"], paths)
        results = {"composite": results, "official": official}
    print(json.dumps(results, indent=2))
    with (out_dir / "metrics.json").open("w") as fh:
        json.dump(results, fh, indent=2)
        fh.write("\n")
    print(f"metrics and submission files saved to {out_dir}")


if __name__ == "__main__":
    main()
