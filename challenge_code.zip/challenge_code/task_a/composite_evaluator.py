"""Composite Task A score used during the challenge phase.

Both challenge-phase scripts carried an evaluator class named
``TrueOriginalEvaluator``; the two variants differ only in the forecast term:

    "lab"      (super.py)            ScoreTA = (F1_A.1 + F1_A.2 + F) / 3,
               F = 0.5 / (1 + MAE_energy) + 0.5 / (1 + MAE_cfp)
    "unified"  (unified_baseline.py) ScoreTA = (F1_A.1 + F1_A.2 + 1 / (1 + MAE_energy)) / 3

Higher is better for both. This is not the ScoreTA of the official starter
kit (``task-a/src/task_a/evaluation.py``, lower is better), which
``evaluate_submission.py`` computes as well.

Labels are derived from the ground-truth frame passed in: a bucket is valid
when its energy is present, and a peak when its energy exceeds the 95th
percentile of its site within that frame. Missing predictions are filled
with "valid", "no peak" and a forecast of zero.
"""

from __future__ import annotations

from typing import Dict

import pandas as pd
from sklearn.metrics import f1_score, mean_absolute_error, precision_score, recall_score


def _prepare(gt_df: pd.DataFrame, forecast_df: pd.DataFrame, det_df: pd.DataFrame,
             peak_df: pd.DataFrame):
    gt = gt_df[["series_id", "bucket_15m", "energy_wh", "cfp_g"]].copy()
    forecasts, detections, peaks = forecast_df.copy(), det_df.copy(), peak_df.copy()
    gt["bucket_15m"] = pd.to_datetime(gt["bucket_15m"], utc=True)
    forecasts["forecast_timestamp_utc"] = pd.to_datetime(forecasts["forecast_timestamp_utc"], utc=True)
    detections["bucket_15m"] = pd.to_datetime(detections["bucket_15m"], utc=True)
    peaks["bucket_15m"] = pd.to_datetime(peaks["bucket_15m"], utc=True)

    gt["is_valid"] = gt["energy_wh"].notna().astype(int)
    threshold = gt.groupby("series_id")["energy_wh"].transform(lambda x: x.quantile(0.95))
    gt["is_peak"] = ((gt["energy_wh"] > threshold) & gt["energy_wh"].notna()).astype(int)

    det_eval = pd.merge(gt[["series_id", "bucket_15m", "is_valid"]],
                        detections[["series_id", "bucket_15m", "valid_signal_pred"]],
                        on=["series_id", "bucket_15m"], how="left")
    det_eval["valid_signal_pred"] = det_eval["valid_signal_pred"].fillna(1)
    peak_eval = pd.merge(gt[["series_id", "bucket_15m", "is_peak"]],
                         peaks[["series_id", "bucket_15m", "peak_pred"]],
                         on=["series_id", "bucket_15m"], how="left")
    peak_eval["peak_pred"] = peak_eval["peak_pred"].fillna(0)

    renamed = gt.rename(columns={"bucket_15m": "forecast_timestamp_utc"})
    horizons = pd.concat([renamed.assign(horizon_steps_15m=4), renamed.assign(horizon_steps_15m=96)],
                         ignore_index=True)
    fc_eval = pd.merge(horizons[["series_id", "forecast_timestamp_utc", "horizon_steps_15m",
                                 "energy_wh", "cfp_g"]],
                       forecasts[["series_id", "forecast_timestamp_utc", "horizon_steps_15m",
                                  "energy_wh_pred", "cfp_g_pred"]],
                       on=["series_id", "forecast_timestamp_utc", "horizon_steps_15m"], how="left")
    fc_eval["energy_wh_pred"] = fc_eval["energy_wh_pred"].fillna(0.0)
    fc_eval["cfp_g_pred"] = fc_eval["cfp_g_pred"].fillna(0.0)
    fc_valid = fc_eval[fc_eval["energy_wh"].notna() & fc_eval["cfp_g"].notna()]
    return det_eval, peak_eval, fc_valid


def _mae(frame: pd.DataFrame, column: str) -> float:
    if frame.empty:
        return 0.0
    return float(mean_absolute_error(frame[column], frame[f"{column}_pred"]))


def score(gt_df: pd.DataFrame, forecast_df: pd.DataFrame, det_df: pd.DataFrame,
          peak_df: pd.DataFrame, variant: str = "lab") -> Dict[str, float]:
    """Composite score and its components (13 metrics)."""
    if variant not in ("lab", "unified"):
        raise ValueError("variant must be 'lab' or 'unified'")
    det_eval, peak_eval, fc_valid = _prepare(gt_df, forecast_df, det_df, peak_df)
    if fc_valid.empty:
        return {"ScoreTA": 0.0, "forecast_mae_energy_wh": float("nan"), "peak_f1": 0.0}

    y_det, p_det = det_eval["is_valid"], det_eval["valid_signal_pred"]
    y_peak, p_peak = peak_eval["is_peak"], peak_eval["peak_pred"]
    det_f1 = float(f1_score(y_det, p_det, zero_division=0))
    peak_f1 = float(f1_score(y_peak, p_peak, zero_division=0))
    mae_energy = _mae(fc_valid, "energy_wh")
    mae_cfp = _mae(fc_valid, "cfp_g")
    h4 = fc_valid[fc_valid["horizon_steps_15m"] == 4]
    h96 = fc_valid[fc_valid["horizon_steps_15m"] == 96]

    if variant == "lab":
        forecast_term = 0.5 * (1.0 / (1.0 + mae_energy)) + 0.5 * (1.0 / (1.0 + mae_cfp))
    else:
        forecast_term = 1.0 / (1.0 + mae_energy)

    return {
        "ScoreTA": (det_f1 + peak_f1 + forecast_term) / 3.0,
        "forecast_mae_energy_wh": mae_energy,
        "forecast_mae_cfp_g": mae_cfp,
        "forecast_mae_energy_wh_horizon_4": _mae(h4, "energy_wh"),
        "forecast_mae_cfp_g_horizon_4": _mae(h4, "cfp_g"),
        "forecast_mae_energy_wh_horizon_96": _mae(h96, "energy_wh"),
        "forecast_mae_cfp_g_horizon_96": _mae(h96, "cfp_g"),
        "detection_f1": det_f1,
        "detection_precision": float(precision_score(y_det, p_det, zero_division=0)),
        "detection_recall": float(recall_score(y_det, p_det, zero_division=0)),
        "peak_f1": peak_f1,
        "peak_precision": float(precision_score(y_peak, p_peak, zero_division=0)),
        "peak_recall": float(recall_score(y_peak, p_peak, zero_division=0)),
    }
