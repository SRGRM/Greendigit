"""Challenge-phase experiment grid for Task A ("model lab").

Trains and scores combinations of a feature strategy and a model
architecture on the public split of the GreenDIGIT data (train <= cut-off <
hold-out). This is the experiment script of the challenge phase
(``super.py`` in the original archive), reorganised and documented; the
training and scoring logic is unchanged, so its numbers can be reproduced:

    Exp_21_Deep_Momentum_Lags_HGB_Absolute_Loss
        ScoreTA (composite, higher is better) 0.38892
        energy MAE 166.17, carbon MAE 164.16, A.1 F1 0.9658, A.2 F1 0.1950

The grid has 3 feature strategies x 9 architectures = 27 experiments (six
HistGradientBoosting variants and three PyTorch MLPs). By default only the
challenge winner Exp_21 runs, as in the last version of the script; set
``CONFIG["experiments"] = "all"`` for the whole grid. The experiment
``GreenGRM_selected`` adds the configuration selected by Green-GRM in the
paper (absolute error, eta 0.01, 200 iterations, depth 5, L2 25).

For every experiment the folder ``<output_dir>/<experiment>/`` receives
the trained models (``models.joblib``, with the feature list under
``__FEATURE_NAMES__``), the composite metrics with the settings of the
experiment, the three Task A files in the official schema and the official
starter-kit score. PyTorch experiments also get ``training_report.csv``
(training losses and hold-out scores after every epoch) and
``epochs/epoch_XXX/`` (weights of the four networks and Task A files of
that epoch); the networks themselves are in ``torch_models.py``. A ranked
report of all experiments is written to
``<output_dir>/experimental_report.txt``.

Note: each model is a one-hour-ahead model (features use values from at
least four buckets earlier) and its forecast is written for both horizons,
as in the challenge-phase submission. The Green-GRM implementation in
``green_grm/`` trains separate 1 h and 24 h models.

Usage (from the repository root):

    python challenge_code/task_a/model_lab.py
"""

from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]

# =============================================================================
# CONFIG
# =============================================================================
CONFIG = {
    # ---- data ------------------------------------------------------------------
    "data_path": REPO_ROOT / "data" / "raw_metrics" / "summary_sites_15m.csv",
    #   alternative: summary_sites_raw.csv (event-level file of the challenge VRE)
    "sites": ("site_ad3433ffac", "site_e726c7cce5", "site_f5bcf8a88a"),
    "split_cutoff_utc": "2026-02-18T14:00:00+00:00",   # train <= cut-off < hold-out

    # ---- experiments -------------------------------------------------------------
    "experiments": ("Exp_21_Deep_Momentum_Lags_HGB_Absolute_Loss", "GreenGRM_selected"),
    #   "all" for the 27-experiment grid, or any tuple of experiment names
    "feature_strategies": [
        {"feat_name": "Base_Time_Lags", "USE_TIME": True, "LAGS": [4, 96],
         "CROSS_VAR": False, "ROLLING": False, "MOMENTUM": False},
        {"feat_name": "AAAI_Cross_Rolling", "USE_TIME": True, "LAGS": [4, 96],
         "CROSS_VAR": True, "ROLLING": True, "MOMENTUM": False},
        {"feat_name": "Deep_Momentum_Lags", "USE_TIME": True, "LAGS": [4, 96, 672],
         "CROSS_VAR": True, "ROLLING": True, "MOMENTUM": True},
    ],
    "model_architectures": [
        # HistGradientBoosting ("HGB"): params go to the two regressors; the
        # classifiers take max_iter only.
        {"mod_name": "HGB_Standard", "type": "HGB", "params": {
            "max_iter": 100, "learning_rate": 0.05, "loss": "squared_error", "max_depth": None,
            "l2_regularization": 0.0}},
        {"mod_name": "HGB_Robust_L2", "type": "HGB", "params": {
            "max_iter": 100, "learning_rate": 0.01, "loss": "squared_error", "max_depth": 7,
            "l2_regularization": 1.5}},
        {"mod_name": "HGB_Absolute_Loss", "type": "HGB", "params": {
            "max_iter": 100, "learning_rate": 0.05, "loss": "absolute_error", "max_depth": None,
            "l2_regularization": 0.5}},
        {"mod_name": "HGB_Fast_Shallow", "type": "HGB", "params": {
            "max_iter": 100, "learning_rate": 0.1, "loss": "squared_error", "max_depth": 5,
            "l2_regularization": 0.0}},
        {"mod_name": "HGB_Deep_Complex", "type": "HGB", "params": {
            "max_iter": 100, "learning_rate": 0.02, "loss": "squared_error", "max_leaf_nodes": 63,
            "l2_regularization": 0.1}},
        {"mod_name": "HGB_Poisson_Count", "type": "HGB", "params": {
            "max_iter": 100, "learning_rate": 0.05, "loss": "poisson", "max_depth": None,
            "l2_regularization": 0.0}},
        # PyTorch MLPs ("PT"): epochs | lr | hidden_dim | layers | dropout
        {"mod_name": "PyTorch_Deep_MLP", "type": "PT", "params": {
            "epochs": 100, "lr": 1e-3, "hidden_dim": 256, "layers": 3, "dropout": 0.1}},
        {"mod_name": "PyTorch_UltraDeep_MLP", "type": "PT", "params": {
            "epochs": 100, "lr": 5e-4, "hidden_dim": 512, "layers": 5, "dropout": 0.3}},
        {"mod_name": "PyTorch_Wide_Shallow", "type": "PT", "params": {
            "epochs": 100, "lr": 1e-3, "hidden_dim": 1024, "layers": 2, "dropout": 0.2}},
    ],
    "extra_experiments": [
        # Configuration selected by Green-GRM (Table 2 of the paper) in this pipeline.
        {"exp_name": "GreenGRM_selected", "features": "Deep_Momentum_Lags",
         "model": {"mod_name": "HGB_GreenGRM", "type": "HGB", "params": {
             "max_iter": 200, "learning_rate": 0.01, "loss": "absolute_error", "max_depth": 5,
             "l2_regularization": 25.0}}},
    ],
    "random_state": 42,

    # ---- PyTorch settings (PT architectures only) ----------------------------------
    "gpu_ids": [0],                 # [] -> CPU | [0] -> one GPU | [0, 1, ...] -> DataParallel
    "batch_size": 8192,             # 4096 | 8192 | 16384
    "weight_decay": 1e-4,           # AdamW weight decay
    "early_stopping_patience": 50,  # epochs without a lower training loss
    "torch_seed": 42,               # torch.manual_seed before each network | None (unseeded, as in super.py)
    "print_every_epochs": 10,       # progress line every N epochs | 1 | 0 (silent)
    "save_epoch_checkpoints": True, # weights of the four networks after every epoch:
                                    #   <experiment>/epochs/epoch_XXX/<target>.pt (up to ~4 MB per file,
                                    #   ~12 GB with the per-epoch files for the nine MLP experiments) | False
    "epoch_submissions": True,      # Task A files and composite score of every epoch, rebuilt from the
                                    #   checkpoints: <experiment>/epochs/epoch_XXX/submission/ and
                                    #   <experiment>/training_report.csv | False (report only)

    # ---- outputs ---------------------------------------------------------------------
    "output_dir": REPO_ROOT / "runs" / "challenge_lab",
    "save_models": True,
    "write_submissions": True,      # three Task A files in the official schema
    "official_score": True,         # score the files with the starter-kit evaluator
}

# =============================================================================

import joblib  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
from sklearn.ensemble import HistGradientBoostingClassifier, HistGradientBoostingRegressor  # noqa: E402

sys.path.insert(0, str(Path(__file__).resolve().parent))
import composite_evaluator  # noqa: E402
from feature_library import DataLoadError, extract_config_features, load_and_build_master_dataset  # noqa: E402


# -----------------------------------------------------------------------------
# Experiment grid
# -----------------------------------------------------------------------------
def build_experiment_grid(config: dict) -> list:
    grid = []
    exp_id = 1
    for feat in config["feature_strategies"]:
        for mod in config["model_architectures"]:
            grid.append({"exp_name": f"Exp_{exp_id:02d}_{feat['feat_name']}_{mod['mod_name']}",
                         "features": feat, "model": mod})
            exp_id += 1
    strategies = {f["feat_name"]: f for f in config["feature_strategies"]}
    for extra in config["extra_experiments"]:
        grid.append({"exp_name": extra["exp_name"], "features": strategies[extra["features"]],
                     "model": extra["model"]})
    if config["experiments"] != "all":
        wanted = list(config["experiments"])
        unknown = sorted(set(wanted) - {e["exp_name"] for e in grid})
        if unknown:
            raise ValueError(f"unknown experiments: {unknown}")
        grid = [e for e in grid if e["exp_name"] in wanted]
    return grid


# -----------------------------------------------------------------------------
# PyTorch models (loaded only when a PT architecture is selected)
# -----------------------------------------------------------------------------
def load_torch_backend(config: dict):
    """Select the GPUs, import the PyTorch models and return a factory for
    the network wrappers of the PT architectures.

    ``gpu_ids`` is applied through CUDA_VISIBLE_DEVICES before torch is
    imported; with more than one GPU the network is wrapped in
    ``nn.DataParallel``. The models (``torch_models.py``) use only features
    of PyTorch 1.8 and later, so the same code runs on the CUDA 11.4 and
    CUDA 12.2 machines.
    """
    gpu_ids = list(config["gpu_ids"])
    if gpu_ids:
        os.environ["CUDA_VISIBLE_DEVICES"] = ",".join(str(g) for g in gpu_ids)
    try:
        import torch
        import torch_models
    except ImportError:
        print("[error] the selected PyTorch experiments need torch; install it or drop them from CONFIG")
        sys.exit(1)

    device = torch.device("cuda" if gpu_ids and torch.cuda.is_available() else "cpu")
    n_gpus = torch.cuda.device_count() if device.type == "cuda" else 0
    print(f"[torch] version {torch.__version__}, device {device}, visible GPUs {n_gpus}")

    def factory(target: str, is_classification: bool, epoch_dir, **params):
        return torch_models.PyTorchWrapper(
            is_classification=is_classification, batch_size=config["batch_size"],
            weight_decay=config["weight_decay"], patience=config["early_stopping_patience"],
            device=device, data_parallel=n_gpus > 1, seed=config["torch_seed"], name=target,
            epoch_dir=epoch_dir, print_every=config["print_every_epochs"], **params)

    return factory


# -----------------------------------------------------------------------------
# Training, prediction and scoring of one experiment
# -----------------------------------------------------------------------------
def train_models(exp: dict, X_train, y: dict, config: dict, torch_factory=None,
                 exp_dir: Path = None) -> dict:
    """The four models of an experiment: energy and carbon regressors, A.1
    (valid signal) and A.2 (peak) classifiers."""
    mod_type, params = exp["model"]["type"], exp["model"]["params"]
    seed = config["random_state"]
    if mod_type == "HGB":
        return {
            "energy": HistGradientBoostingRegressor(**params, random_state=seed).fit(X_train, y["energy"]),
            "cfp": HistGradientBoostingRegressor(**params, random_state=seed).fit(X_train, y["cfp"]),
            "det": HistGradientBoostingClassifier(max_iter=params.get("max_iter", 100),
                                                  random_state=seed).fit(X_train, y["valid"]),
            "peak": HistGradientBoostingClassifier(max_iter=params.get("max_iter", 100),
                                                   class_weight="balanced",
                                                   random_state=seed).fit(X_train, y["peak"]),
        }
    if mod_type == "PT":
        epoch_dir = exp_dir / "epochs" if config["save_epoch_checkpoints"] else None
        models = {}
        for target, label, is_class in (("energy", "energy", False), ("cfp", "cfp", False),
                                        ("det", "valid", True), ("peak", "peak", True)):
            print(f"   [{target}] training the network ...")
            net = torch_factory(target, is_class, epoch_dir, **params)
            models[target] = net.fit(X_train, y[label])
        return models
    raise ValueError(f"unknown model type {mod_type}")


def epoch_report(models: dict, test_df: pd.DataFrame, X_test, exp_dir: Path, config: dict) -> pd.DataFrame:
    """Training report of a PyTorch experiment, one row per epoch.

    Holds the training loss of the four networks and, when the weights of
    every epoch were saved and ``epoch_submissions`` is on, the composite
    score of the hold-out predictions of that epoch, whose Task A files are
    written to ``<experiment>/epochs/epoch_XXX/submission/``. A network that
    stopped early keeps its last weights in the later epochs. The networks
    are left with their final weights.
    """
    n_epochs = max(net.epochs_run for net in models.values())
    replay = config["save_epoch_checkpoints"] and config["epoch_submissions"]
    rows = []
    for epoch in range(1, n_epochs + 1):
        row = {"epoch": epoch}
        for target, net in models.items():
            done = epoch > net.epochs_run
            step = net.history[min(epoch, net.epochs_run) - 1]
            row[f"train_loss_{target}"] = np.nan if done else step["train_loss"]
            row[f"best_loss_{target}"] = step["best_loss"]
        if replay:
            for net in models.values():
                net.load_epoch(epoch)
            forecast_df, det_df, peak_df = predict_tables(models, test_df, X_test)
            scores = composite_evaluator.score(test_df, forecast_df, det_df, peak_df, variant="lab")
            row.update({"composite_ScoreTA": scores["ScoreTA"],
                        "mae_energy_wh": scores["forecast_mae_energy_wh"],
                        "mae_cfp_g": scores["forecast_mae_cfp_g"],
                        "detection_f1": scores["detection_f1"], "peak_f1": scores["peak_f1"]})
            write_submission(exp_dir / "epochs" / f"epoch_{epoch:03d}" / "submission",
                             forecast_df, det_df, peak_df)
        rows.append(row)
    if replay:
        for net in models.values():
            net.load_epoch(n_epochs)
    report = pd.DataFrame(rows)
    report.to_csv(exp_dir / "training_report.csv", index=False)
    if replay:
        best = report.loc[report["composite_ScoreTA"].idxmax()]
        print(f"   training report: {n_epochs} epochs, best composite ScoreTA "
              f"{best['composite_ScoreTA']:.5f} after epoch {int(best['epoch'])}")
    return report


def predict_tables(models: dict, test_df: pd.DataFrame, X_test) -> tuple:
    """Forecast, detection and peak tables for the hold-out buckets."""
    keys = {"series_id": test_df["series_id"].to_numpy(), "bucket_15m": test_df["bucket_15m"].to_numpy()}
    det_df = pd.DataFrame({**keys, "valid_signal_score": models["det"].predict_proba(X_test)[:, 1],
                           "valid_signal_pred": models["det"].predict(X_test).astype(int)})
    peak_df = pd.DataFrame({**keys, "peak_score": models["peak"].predict_proba(X_test)[:, 1],
                            "peak_pred": models["peak"].predict(X_test).astype(int)})
    energy = np.clip(models["energy"].predict(X_test), a_min=0, a_max=None)
    cfp = np.clip(models["cfp"].predict(X_test), a_min=0, a_max=None)
    forecast_df = pd.concat([
        pd.DataFrame({"series_id": keys["series_id"], "forecast_timestamp_utc": keys["bucket_15m"],
                      "horizon_steps_15m": h, "energy_wh_pred": energy, "cfp_g_pred": cfp})
        for h in (4, 96)], ignore_index=True)
    return forecast_df, det_df, peak_df


def write_submission(folder: Path, forecast_df, det_df, peak_df) -> dict:
    """Write the three files with ISO timestamps (official schema)."""
    folder.mkdir(parents=True, exist_ok=True)

    def iso(series):
        return pd.to_datetime(series, utc=True).dt.strftime("%Y-%m-%dT%H:%M:%S+00:00")

    paths = {"forecasts": folder / "forecast_submission.csv",
             "detections": folder / "detection_submission.csv",
             "peaks": folder / "peak_submission.csv"}
    forecast_df.assign(forecast_timestamp_utc=iso(forecast_df["forecast_timestamp_utc"])).to_csv(
        paths["forecasts"], index=False)
    det_df.assign(bucket_15m=iso(det_df["bucket_15m"])).to_csv(paths["detections"], index=False)
    peak_df.assign(bucket_15m=iso(peak_df["bucket_15m"])).to_csv(paths["peaks"], index=False)
    return paths


def official_score(paths: dict, config: dict) -> dict:
    """Starter-kit ScoreTA (lower is better) of the three files."""
    from evaluate_submission import official_task_a_score
    return official_task_a_score(config["data_path"], config["split_cutoff_utc"], paths)


# -----------------------------------------------------------------------------
def run_laboratory(config: dict) -> None:
    grid = build_experiment_grid(config)
    print("=" * 80)
    print(f" Task A model lab: {len(grid)} experiment(s)")
    print("=" * 80)

    try:
        df_full = load_and_build_master_dataset(config["data_path"], config["sites"])
    except DataLoadError as exc:
        print(f"[error] {exc} -- stopping.")
        sys.exit(1)
    cutoff = pd.Timestamp(config["split_cutoff_utc"])
    train_df = df_full[df_full["bucket_15m"] <= cutoff]
    test_df = df_full[df_full["bucket_15m"] > cutoff]
    if train_df.empty or test_df.empty:
        print(f"[error] the cut-off {cutoff} leaves no training or hold-out buckets -- stopping.")
        sys.exit(1)
    print(f"[data] train {len(train_df):,} buckets <= {cutoff} < hold-out {len(test_df):,} buckets")
    targets = {"energy": train_df["energy_wh"].fillna(0), "cfp": train_df["cfp_g"].fillna(0),
               "valid": train_df["is_valid"], "peak": train_df["is_peak"]}

    torch_factory = None
    if any(e["model"]["type"] == "PT" for e in grid):
        torch_factory = load_torch_backend(config)

    out_dir = Path(config["output_dir"])
    out_dir.mkdir(parents=True, exist_ok=True)
    registry = []
    for i, exp in enumerate(grid, start=1):
        name = exp["exp_name"]
        print(f"\n[{i}/{len(grid)}] training {name}")
        exp_dir = out_dir / name
        exp_dir.mkdir(parents=True, exist_ok=True)
        features = extract_config_features(train_df, exp["features"])
        X_train, X_test = train_df[features], test_df[features]
        start = time.time()
        models = train_models(exp, X_train, targets, config, torch_factory, exp_dir)
        print(f"   trained in {time.time() - start:.1f} s, predicting the hold-out ...")
        if exp["model"]["type"] == "PT":
            epoch_report(models, test_df, X_test, exp_dir, config)
        forecast_df, det_df, peak_df = predict_tables(models, test_df, X_test)

        scores = composite_evaluator.score(test_df, forecast_df, det_df, peak_df, variant="lab")
        print(f"   composite ScoreTA {scores['ScoreTA']:.5f} | energy MAE {scores['forecast_mae_energy_wh']:.3f}"
              f" | peak F1 {scores['peak_f1']:.3f}")
        result = {"Experiment": name, "features": exp["features"]["feat_name"],
                  "model": exp["model"], **scores}

        if config["save_models"]:
            models["__FEATURE_NAMES__"] = features
            joblib.dump(models, exp_dir / "models.joblib")
            print(f"   models saved to {exp_dir / 'models.joblib'}")
        if config["write_submissions"]:
            paths = write_submission(exp_dir / "submission", forecast_df, det_df, peak_df)
            if config["official_score"]:
                official = official_score(paths, config)
                result["official_ScoreTA"] = official["ScoreTA"]
                with (exp_dir / "metrics_official.json").open("w") as fh:
                    json.dump(official, fh, indent=2)
                print(f"   official starter-kit ScoreTA {official['ScoreTA']:.5f} (lower is better)")
        with (exp_dir / "metrics.json").open("w") as fh:
            json.dump(result, fh, indent=2)
        registry.append(result)

    registry.sort(key=lambda r: r["ScoreTA"], reverse=True)
    lines = ["GreenDIGIT Task A: model lab report", "=" * 60, ""]
    for rank, res in enumerate(registry, start=1):
        # "ScoreTA" is the name super.py gave to its composite score (higher is better)
        line = (f"Rank {rank} | {res['Experiment']} | composite ScoreTA: {res['ScoreTA']:.5f} | "
                f"MAE: {res['forecast_mae_energy_wh']:.3f} | Peak F1: {res['peak_f1']:.3f}")
        if "official_ScoreTA" in res:
            line += f" | official ScoreTA (lower is better): {res['official_ScoreTA']:.5f}"
        lines.append(line)
    report = out_dir / "experimental_report.txt"
    report.write_text("\n".join(lines) + "\n")
    print("\n" + "\n".join(lines[3:13]))
    print(f"\n{len(registry)} experiment(s) evaluated; report saved to {report}")


if __name__ == "__main__":
    run_laboratory(CONFIG)
