"""Score a Task A submission folder (three CSV files) on the public split.

Computes the official starter-kit ScoreTA (``task-a`` evaluator,
0.7 * mean sMAPE term + 0.15 * S(A.1) + 0.15 * S(A.2), lower is better)
and, optionally, the challenge-phase composite score of
``composite_evaluator.py`` (higher is better). This is the standalone
evaluator of the challenge phase (``evaluate_custom.py``) extended with the
composite score.

Usage (from the repository root):

    python challenge_code/task_a/evaluate_submission.py --submission-dir runs/.../submission
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]

# =============================================================================
# CONFIG
# =============================================================================
CONFIG = {
    "data_path": REPO_ROOT / "data" / "raw_metrics" / "summary_sites_15m.csv",
    "split_cutoff_utc": "2026-02-18T14:00:00+00:00",
    "submission_dir": REPO_ROOT / "task-a" / "outputs",   # folder with the three CSV files
    "output_name": "custom_metrics.json",                 # written into the submission folder
    "eps": 1e-9,                                          # sMAPE denominator floor (official value)
    "peak_quantile": 0.95,                                # official value
    "composite": True,                                    # also compute the challenge-phase composite score
    "composite_variant": "lab",                           # "lab" (super.py) | "unified" (unified_baseline.py)
}
FILES = {"forecasts": "forecast_submission.csv", "detections": "detection_submission.csv",
         "peaks": "peak_submission.csv"}

# =============================================================================


def _import_task_a():
    """The official package: installed with ``pip install -e task-a`` or
    taken from the repository."""
    if importlib.util.find_spec("task_a") is None:
        sys.path.insert(0, str(REPO_ROOT / "task-a" / "src"))


def official_task_a_score(data_path: Path, cutoff: str, paths: dict, eps: float = 1e-9,
                          peak_quantile: float = 0.95) -> dict:
    _import_task_a()
    from task_a.dataio import load_series_csv, split_temporal
    from task_a.evaluation import (compose_task_a_score, load_detections, load_forecasts, load_peaks,
                                   score_detection, score_forecasts, score_peaks)
    from task_a.submission import validate_detection_csv, validate_forecast_csv, validate_peak_csv

    validate_forecast_csv(paths["forecasts"])
    validate_detection_csv(paths["detections"])
    validate_peak_csv(paths["peaks"])
    rows = load_series_csv(data_path)
    train, test = split_temporal(rows, cutoff)
    metrics = {}
    metrics.update(score_forecasts(test, load_forecasts(paths["forecasts"]), eps, require_complete=True))
    metrics.update(score_detection(test, load_detections(paths["detections"])))
    metrics.update(score_peaks(train, test, peak_quantile, load_peaks(paths["peaks"])))
    metrics["ScoreTA"] = compose_task_a_score(metrics)
    return metrics


def composite_task_a_score(data_path: Path, cutoff: str, paths: dict, variant: str = "lab") -> dict:
    import pandas as pd

    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import composite_evaluator
    from feature_library import load_ground_truth

    truth = load_ground_truth(data_path)
    truth = truth[truth["bucket_15m"] > pd.Timestamp(cutoff)]
    return composite_evaluator.score(truth, pd.read_csv(paths["forecasts"]), pd.read_csv(paths["detections"]),
                                     pd.read_csv(paths["peaks"]), variant=variant)


def main() -> None:
    parser = argparse.ArgumentParser(description="Score a Task A submission folder")
    parser.add_argument("--submission-dir", type=Path, default=None)
    parser.add_argument("--data", type=Path, default=None, help="telemetry file with the public data")
    parser.add_argument("--cutoff", default=None)
    args = parser.parse_args()

    config = dict(CONFIG)
    if args.submission_dir:
        config["submission_dir"] = args.submission_dir
    if args.data:
        config["data_path"] = args.data
    if args.cutoff:
        config["split_cutoff_utc"] = args.cutoff

    folder = Path(config["submission_dir"])
    paths = {key: folder / name for key, name in FILES.items()}
    missing = [str(p) for p in paths.values() if not p.is_file()]
    if missing or not Path(config["data_path"]).is_file():
        print(f"[error] missing input files: {missing or config['data_path']} -- stopping.")
        sys.exit(1)

    print(f"[eval] scoring {folder} against {config['data_path']} (cut-off {config['split_cutoff_utc']})")
    result = {"official": official_task_a_score(config["data_path"], config["split_cutoff_utc"], paths,
                                                config["eps"], config["peak_quantile"])}
    print(f"[eval] official ScoreTA = {result['official']['ScoreTA']:.5f} (lower is better)")
    if config["composite"]:
        result["composite"] = composite_task_a_score(config["data_path"], config["split_cutoff_utc"], paths,
                                                     config["composite_variant"])
        print(f"[eval] composite ScoreTA ({config['composite_variant']}) = "
              f"{result['composite']['ScoreTA']:.5f} (higher is better)")
    out_path = folder / config["output_name"]
    with out_path.open("w") as fh:
        json.dump(result, fh, indent=2)
        fh.write("\n")
    print(json.dumps(result, indent=2))
    print(f"[eval] metrics saved to {out_path}")


if __name__ == "__main__":
    main()
