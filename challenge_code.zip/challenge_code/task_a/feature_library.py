"""Data loading and feature library of the challenge-phase experiments.

This is the feature pipeline of the original experiment grid (``super.py``
in the challenge archive), kept with the same behaviour so that its results
can be reproduced:

* site/VO rows are summed per (site, 15-minute bucket); ``pue`` and
  ``ci_g`` (only present in the event-level file) are averaged,
* every site is resampled to a strict 15-minute grid,
* the features of a bucket t only use values at t-4 or earlier, so a model
  trained on them is a one-hour-ahead forecaster,
* missing values are replaced by 0 at the end.

Feature columns (prefix ``F_``):

    F_hour, F_dow                     calendar of the bucket
    F_energy_lag_h, F_cfp_lag_h       h in (4, 8, 96, 672)
    F_work_lag_h, F_ncores_lag_h      h in (4, 96)
    F_energy_roll_3h, F_cfp_roll_3h   mean of t-15 .. t-4 (12 buckets)
    F_energy_momentum, F_cfp_momentum lag 4 minus lag 8

Labels: ``is_valid`` (energy present before the zero filling) and
``is_peak`` (energy above the 95th percentile of its site, computed over the
whole series as in the original runs).
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Sequence

import pandas as pd

DEFAULT_SITES = ("site_ad3433ffac", "site_e726c7cce5", "site_f5bcf8a88a")
LAG_STEPS = (4, 8, 96, 672)
WORKLOAD_LAG_STEPS = (4, 96)


class DataLoadError(RuntimeError):
    """The input data is missing or unusable; the scripts stop on it."""


def load_and_build_master_dataset(csv_path: Path, sites: Sequence[str] = DEFAULT_SITES,
                                  verbose: bool = True) -> pd.DataFrame:
    """Load the telemetry and build the full feature library."""
    csv_path = Path(csv_path)
    if not csv_path.is_file():
        raise DataLoadError(f"data file not found: {csv_path}")
    if verbose:
        print(f"[data] loading {csv_path} ...")
    df = pd.read_csv(csv_path)
    if df.empty:
        raise DataLoadError(f"{csv_path} is empty")

    df = df.rename(columns={"event_start_timestamp": "bucket_15m", "site_id": "series_id"})
    for column in ("bucket_15m", "series_id", "energy_wh", "cfp_g"):
        if column not in df.columns:
            raise DataLoadError(f"{csv_path} has no column '{column}'")
    df["bucket_15m"] = pd.to_datetime(df["bucket_15m"], utc=True)
    df = df[df["series_id"].isin(list(sites))]
    if df.empty:
        raise DataLoadError(f"none of the sites {list(sites)} occurs in {csv_path}")

    agg_cols = [c for c in ("energy_wh", "cfp_g", "work", "ncores", "pue", "ci_g") if c in df.columns]
    agg = {col: "mean" if col in ("pue", "ci_g") else "sum" for col in agg_cols}
    df = df.groupby(["series_id", "bucket_15m"]).agg(agg).reset_index()

    if verbose:
        print("[data] resampling every site to a strict 15-minute grid ...")
    frames = []
    for site in sites:
        site_df = df[df["series_id"] == site].copy()
        if site_df.empty:
            continue
        site_df = site_df.set_index("bucket_15m").resample("15min").asfreq()
        if site_df.index.tzinfo is None:
            site_df.index = site_df.index.tz_localize("UTC")
        site_df = site_df.reset_index()
        site_df["series_id"] = site
        frames.append(site_df)
    df = pd.concat(frames, ignore_index=True)

    if verbose:
        print("[data] building the feature library ...")
    df["F_hour"] = df["bucket_15m"].dt.hour
    df["F_dow"] = df["bucket_15m"].dt.dayofweek
    by_site = df.groupby("series_id")
    for h in LAG_STEPS:
        df[f"F_energy_lag_{h}"] = by_site["energy_wh"].shift(h)
        df[f"F_cfp_lag_{h}"] = by_site["cfp_g"].shift(h)
    for column in ("work", "ncores"):
        if column in df.columns:
            for h in WORKLOAD_LAG_STEPS:
                df[f"F_{column}_lag_{h}"] = by_site[column].shift(h)

    df["F_energy_roll_3h"] = by_site["energy_wh"].transform(
        lambda x: x.shift(4).rolling(12, min_periods=1).mean())
    df["F_cfp_roll_3h"] = by_site["cfp_g"].transform(
        lambda x: x.shift(4).rolling(12, min_periods=1).mean())
    df["F_energy_momentum"] = df["F_energy_lag_4"] - df["F_energy_lag_8"]
    df["F_cfp_momentum"] = df["F_cfp_lag_4"] - df["F_cfp_lag_8"]

    df["is_valid"] = df["energy_wh"].notna().astype(int)
    peak_threshold = df.groupby("series_id")["energy_wh"].transform(lambda x: x.quantile(0.95))
    df["is_peak"] = ((df["energy_wh"] > peak_threshold) & df["energy_wh"].notna()).astype(int)

    if verbose:
        print(f"[data] {len(df):,} buckets for {df['series_id'].nunique()} sites, "
              f"{df['bucket_15m'].min()} .. {df['bucket_15m'].max()}")
    return df.fillna(0)


def extract_config_features(df: pd.DataFrame, feature_strategy: Dict) -> List[str]:
    """Feature columns selected by one feature strategy."""
    selected: List[str] = []
    if feature_strategy["USE_TIME"]:
        selected += ["F_hour", "F_dow"]
    for h in feature_strategy["LAGS"]:
        selected += [f"F_energy_lag_{h}", f"F_cfp_lag_{h}"]
    if feature_strategy["CROSS_VAR"]:
        selected += [c for c in df.columns if c.startswith("F_work_lag") or c.startswith("F_ncores_lag")]
    if feature_strategy["ROLLING"]:
        selected += ["F_energy_roll_3h", "F_cfp_roll_3h"]
    if feature_strategy["MOMENTUM"]:
        selected += ["F_energy_momentum", "F_cfp_momentum"]
    return [c for c in selected if c in df.columns]


def load_ground_truth(csv_path: Path, sites: Sequence[str] = DEFAULT_SITES) -> pd.DataFrame:
    """Site-level series on the 15-minute grid with gaps kept as NaN
    (the ground-truth loader of ``unified_baseline.py``)."""
    csv_path = Path(csv_path)
    if not csv_path.is_file():
        raise DataLoadError(f"data file not found: {csv_path}")
    df = pd.read_csv(csv_path).rename(columns={"event_start_timestamp": "bucket_15m",
                                               "site_id": "series_id"})
    df["bucket_15m"] = pd.to_datetime(df["bucket_15m"], utc=True)
    df = df[df["series_id"].isin(list(sites))]
    df = df.groupby(["series_id", "bucket_15m"])[["energy_wh", "cfp_g"]].sum().reset_index()
    frames = []
    for site in sites:
        site_df = df[df["series_id"] == site]
        if site_df.empty:
            continue
        site_df = site_df.set_index("bucket_15m").resample("15min").asfreq()
        if site_df.index.tzinfo is None:
            site_df.index = site_df.index.tz_localize("UTC")
        site_df = site_df.reset_index()
        site_df["series_id"] = site
        frames.append(site_df)
    if not frames:
        raise DataLoadError(f"none of the sites {list(sites)} occurs in {csv_path}")
    return pd.concat(frames, ignore_index=True)[["series_id", "bucket_15m", "energy_wh", "cfp_g"]]
