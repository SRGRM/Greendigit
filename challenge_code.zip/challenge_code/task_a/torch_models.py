"""PyTorch MLPs of the challenge-phase model lab (``model_lab.py``).

The network and its scikit-learn style wrapper come from ``super.py``; the
training loop is unchanged (AdamW, MSE or BCE loss, early stopping on the
training loss). Additions:

* per-epoch history (training loss, best loss, epochs without improvement,
  time) and, optionally, the weights of every epoch on disk, so that the
  lab can rebuild the predictions of any epoch;
* a seed per network (``torch.manual_seed``) for repeatable CPU runs;
* saving and loading with joblib: the weights are stored on the CPU and
  moved to the available device when a saved model is loaded.

Import this module only after ``CUDA_VISIBLE_DEVICES`` has been set;
``model_lab.py`` sets it from ``CONFIG["gpu_ids"]`` first. Only features of
PyTorch 1.8 and later are used.
"""

from __future__ import annotations

import time
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import torch
import torch.nn as nn
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from torch.utils.data import DataLoader, TensorDataset


def available_device() -> torch.device:
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


class AdvancedTabularNet(nn.Module):
    """MLP blocks of Linear -> BatchNorm -> GELU -> Dropout and a linear head."""

    def __init__(self, input_dim: int, hidden_dim: int = 256, num_layers: int = 3, dropout: float = 0.2):
        super().__init__()
        layers, in_dim = [], input_dim
        for _ in range(num_layers):
            layers += [nn.Linear(in_dim, hidden_dim), nn.BatchNorm1d(hidden_dim), nn.GELU(),
                       nn.Dropout(dropout)]
            in_dim = hidden_dim
        self.feature_extractor = nn.Sequential(*layers)
        self.head = nn.Linear(hidden_dim, 1)

    def forward(self, x):
        return self.head(self.feature_extractor(x)).squeeze(-1)


class PyTorchWrapper:
    """fit / predict / predict_proba around ``AdvancedTabularNet``.

    Missing values are filled with 0 and the features standardised, since
    the network cannot take NaN or unscaled inputs.

    Parameters
    ----------
    is_classification : BCE loss and probability outputs instead of MSE.
    epochs, lr, hidden_dim, layers, dropout : architecture and training
        settings of the lab grid.
    batch_size, weight_decay, patience : mini-batch size, AdamW weight decay
        and number of epochs without a lower training loss before stopping.
    device : torch device for training; ``data_parallel`` wraps the network
        in ``nn.DataParallel`` (more than one visible GPU).
    seed : seed of ``torch.manual_seed`` before training (None: not seeded,
        as in ``super.py``).
    name : label used in progress lines and checkpoint file names.
    epoch_dir : if given, the weights after every epoch are written to
        ``<epoch_dir>/epoch_XXX/<name>.pt``.
    print_every : progress line every ``print_every`` epochs (0: silent).
    """

    def __init__(self, is_classification: bool = False, epochs: int = 100, lr: float = 1e-3,
                 hidden_dim: int = 256, layers: int = 3, dropout: float = 0.2, batch_size: int = 8192,
                 weight_decay: float = 1e-4, patience: int = 50, device: Optional[torch.device] = None,
                 data_parallel: bool = False, seed: Optional[int] = None, name: str = "model",
                 epoch_dir: Optional[Path] = None, print_every: int = 10):
        self.is_class = is_classification
        self.epochs, self.lr = epochs, lr
        self.hidden_dim, self.layers, self.dropout = hidden_dim, layers, dropout
        self.batch_size, self.weight_decay, self.patience = batch_size, weight_decay, patience
        self.device = device if device is not None else available_device()
        self.data_parallel = data_parallel
        self.seed, self.name = seed, name
        self.epoch_dir = Path(epoch_dir) if epoch_dir is not None else None
        self.print_every = print_every
        self.imputer = SimpleImputer(strategy="constant", fill_value=0.0)
        self.scaler = StandardScaler()
        self.model: Optional[nn.Module] = None
        self.input_dim: Optional[int] = None
        self.history: List[Dict[str, float]] = []

    # ------------------------------------------------------------------ training
    def _network(self) -> nn.Module:
        """The bare network (without the DataParallel wrapper)."""
        return self.model.module if isinstance(self.model, nn.DataParallel) else self.model

    def checkpoint_path(self, epoch: int) -> Path:
        return self.epoch_dir / f"epoch_{epoch:03d}" / f"{self.name}.pt"

    def fit(self, X, y) -> "PyTorchWrapper":
        if self.seed is not None:
            torch.manual_seed(self.seed)
        X_proc = self.scaler.fit_transform(self.imputer.fit_transform(X))
        dataset = TensorDataset(torch.tensor(X_proc, dtype=torch.float32),
                                torch.tensor(np.asarray(y, dtype=np.float32)))
        # A last batch of one row would stop BatchNorm in training mode.
        drop_last = len(dataset) % self.batch_size == 1
        loader = DataLoader(dataset, batch_size=self.batch_size, shuffle=True, drop_last=drop_last)
        self.input_dim = X_proc.shape[1]
        net = AdvancedTabularNet(self.input_dim, self.hidden_dim, self.layers, self.dropout)
        if self.data_parallel:
            net = nn.DataParallel(net)
        self.model = net.to(self.device)
        criterion = nn.BCEWithLogitsLoss() if self.is_class else nn.MSELoss()
        optimizer = torch.optim.AdamW(self.model.parameters(), lr=self.lr, weight_decay=self.weight_decay)

        best, waited = float("inf"), 0
        self.history = []
        started = time.time()
        self.model.train()
        for epoch in range(1, self.epochs + 1):
            total = 0.0
            for batch_x, batch_y in loader:
                batch_x, batch_y = batch_x.to(self.device), batch_y.to(self.device)
                optimizer.zero_grad()
                loss = criterion(self.model(batch_x), batch_y)
                loss.backward()
                optimizer.step()
                total += loss.item()
            avg = total / len(loader)
            if avg < best:
                best, waited = avg, 0
            else:
                waited += 1
            self.history.append({"epoch": epoch, "train_loss": avg, "best_loss": best,
                                 "epochs_without_improvement": waited,
                                 "seconds": round(time.time() - started, 2)})
            if self.epoch_dir is not None:
                path = self.checkpoint_path(epoch)
                path.parent.mkdir(parents=True, exist_ok=True)
                torch.save({k: v.detach().cpu() for k, v in self._network().state_dict().items()}, path)
            stopping = waited >= self.patience
            if self.print_every and (epoch % self.print_every == 0 or epoch == self.epochs or stopping):
                print(f"      [{self.name}] epoch {epoch:3d}/{self.epochs} train loss {avg:.4g} "
                      f"(best {best:.4g}){' -- early stop' if stopping else ''}")
            if stopping:
                break
        self.model.eval()
        return self

    @property
    def epochs_run(self) -> int:
        return len(self.history)

    def load_epoch(self, epoch: int) -> None:
        """Load the weights saved after ``epoch`` (the last epoch if the
        network stopped earlier). Needs ``epoch_dir``."""
        if self.epoch_dir is None:
            raise ValueError("load_epoch needs the per-epoch checkpoints (epoch_dir)")
        state = torch.load(self.checkpoint_path(min(epoch, self.epochs_run)), map_location=self.device)
        self._network().load_state_dict(state)

    # ---------------------------------------------------------------- prediction
    def _forward(self, X):
        self.model.eval()
        X_proc = self.scaler.transform(self.imputer.transform(X))
        with torch.no_grad():
            return self.model(torch.tensor(X_proc, dtype=torch.float32).to(self.device))

    def predict(self, X):
        out = self._forward(X)
        if self.is_class:
            return (torch.sigmoid(out) > 0.5).cpu().numpy().astype(int)
        return out.cpu().numpy()

    def predict_proba(self, X):
        p = torch.sigmoid(self._forward(X)).cpu().numpy()
        return np.column_stack([1.0 - p, p])

    # ------------------------------------------------------------- persistence
    def __getstate__(self):
        state = self.__dict__.copy()
        state["model"] = None
        state["device"] = None
        state["data_parallel"] = False
        state["state_dict"] = (None if self.model is None else
                               {k: v.detach().cpu() for k, v in self._network().state_dict().items()})
        return state

    def __setstate__(self, state):
        weights = state.pop("state_dict", None)
        self.__dict__.update(state)
        self.device = available_device()
        if weights is not None:
            net = AdvancedTabularNet(self.input_dim, self.hidden_dim, self.layers, self.dropout)
            net.load_state_dict(weights)
            self.model = net.to(self.device).eval()
