"""Random-forest starting point of the challenge phase (Task A).

The first model written for the challenge (``run_custom_model.py`` in the
archive): calendar features only (site, hour of day, day of week) and random
forests for the forecasts, the A.1 detector and the A.2 detector, using the
data loader, labels and file writers of the official starter kit. Local
official ScoreTA of this model: 0.7578 (starter-kit baseline: 0.7646).

Usage (from the repository root):

    python challenge_code/task_a/random_forest_baseline.py
"""

from __future__ import annotations

import importlib.util
import sys
from datetime import timedelta
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]

# =============================================================================
# CONFIG
# =============================================================================
CONFIG = {
    "data_path": REPO_ROOT / "data" / "raw_metrics" / "summary_sites_15m.csv",
    "split_cutoff_utc": "2026-02-18T14:00:00+00:00",
    "output_dir": REPO_ROOT / "runs" / "random_forest_baseline",
    "horizons": (4, 96),                  # 15-minute steps (1 h, 24 h)
    "n_estimators": 50,                   # trees per forest | 100 | 200
    "random_state": 42,
    "n_jobs": -1,                         # -1 = all cores
    "peak_quantile": 0.95,
}

# =============================================================================

import pandas as pd  # noqa: E402
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor  # noqa: E402
from sklearn.preprocessing import LabelEncoder  # noqa: E402

if importlib.util.find_spec("task_a") is None:   # not pip-installed: use the bundled copy
    sys.path.insert(0, str(REPO_ROOT / "task-a" / "src"))

from task_a.dataio import load_series_csv, split_temporal  # noqa: E402
from task_a.labels import peak_label, peak_threshold, valid_signal_label  # noqa: E402
from task_a.schemas import DetectionRow, ForecastRow, PeakRow  # noqa: E402
from task_a.submission import write_detections, write_forecasts, write_peaks  # noqa: E402

FEATURES = ["series_idx", "hour", "day_of_week"]


def extract_features(rows, encoder=None):
    """Calendar features of each 15-minute bucket; the raw row is kept to
    derive the labels later."""
    frame = pd.DataFrame([{
        "series_id": row.series_id, "hour": row.bucket_15m.hour,
        "day_of_week": row.bucket_15m.weekday(), "energy_wh": row.energy_wh,
        "cfp_g": row.cfp_g, "raw_row": row,
    } for row in rows])
    if encoder is None:
        encoder = LabelEncoder()
        frame["series_idx"] = encoder.fit_transform(frame["series_id"])
    else:
        known = set(encoder.classes_)
        safe = frame["series_id"].apply(lambda s: s if s in known else encoder.classes_[0])
        frame["series_idx"] = encoder.transform(safe)
    return frame, encoder


def main(config: dict) -> None:
    out_dir = Path(config["output_dir"])
    out_dir.mkdir(parents=True, exist_ok=True)
    data_path = Path(config["data_path"])
    if not data_path.is_file():
        print(f"[error] data file not found: {data_path} -- stopping.")
        sys.exit(1)

    print("[data] loading and splitting the series ...")
    rows = load_series_csv(data_path)
    train_rows, test_rows = split_temporal(rows, config["split_cutoff_utc"])
    if not train_rows or not test_rows:
        print("[error] empty training or test split -- stopping.")
        sys.exit(1)
    train_df, encoder = extract_features(train_rows)
    test_df, _ = extract_features(test_rows, encoder=encoder)
    print(f"[data] {len(train_df):,} training and {len(test_df):,} test buckets")

    # Forecasts: one multi-output forest for energy and carbon.
    print("[model] training the forecast forest ...")
    forest = RandomForestRegressor(n_estimators=config["n_estimators"], random_state=config["random_state"],
                                   n_jobs=config["n_jobs"])
    forest.fit(train_df[FEATURES], train_df[["energy_wh", "cfp_g"]])

    print("[predict] forecasts for every test origin ...")
    series_ids = sorted({row.series_id for row in rows})
    origins = sorted({row.bucket_15m for row in test_rows})
    future, meta = [], []
    for series_id in series_ids:
        safe = series_id if series_id in encoder.classes_ else encoder.classes_[0]
        series_idx = encoder.transform([safe])[0]
        for origin in origins:
            for horizon in config["horizons"]:
                ts = origin + timedelta(minutes=15 * horizon)
                future.append({"series_idx": series_idx, "hour": ts.hour, "day_of_week": ts.weekday()})
                meta.append((series_id, ts, horizon))
    predictions = forest.predict(pd.DataFrame(future)[FEATURES])
    forecasts = [ForecastRow(sid, ts, h, max(0.0, float(p[0])), max(0.0, float(p[1])))
                 for (sid, ts, h), p in zip(meta, predictions)]
    write_forecasts(forecasts, out_dir / "forecast_submission.csv")

    # A.1: valid / invalid telemetry.
    print("[model] training the A.1 detector ...")
    detector = RandomForestClassifier(n_estimators=config["n_estimators"], random_state=config["random_state"],
                                      n_jobs=config["n_jobs"])
    detector.fit(train_df[FEATURES], train_df["raw_row"].apply(valid_signal_label))
    det_scores = detector.predict_proba(test_df[FEATURES])
    det_scores = det_scores[:, 1] if det_scores.shape[1] > 1 else det_scores[:, 0]
    det_preds = detector.predict(test_df[FEATURES])
    write_detections([DetectionRow(r.series_id, r.bucket_15m, float(s), int(p))
                      for r, s, p in zip(test_rows, det_scores, det_preds)],
                     out_dir / "detection_submission.csv")

    # A.2: peaks, labelled with the thresholds of the training split.
    print("[model] training the A.2 detector ...")
    thresholds = peak_threshold(train_rows, config["peak_quantile"])
    peak_forest = RandomForestClassifier(n_estimators=config["n_estimators"],
                                         random_state=config["random_state"], n_jobs=config["n_jobs"])
    peak_forest.fit(train_df[FEATURES], train_df["raw_row"].apply(lambda r: peak_label(r, thresholds)))
    peak_scores = peak_forest.predict_proba(test_df[FEATURES])[:, 1]
    peak_preds = peak_forest.predict(test_df[FEATURES])
    write_peaks([PeakRow(r.series_id, r.bucket_15m, float(s), int(p))
                 for r, s, p in zip(test_rows, peak_scores, peak_preds)],
                out_dir / "peak_submission.csv")
    print(f"[done] the three submission files are in {out_dir}")


if __name__ == "__main__":
    main(CONFIG)
