"""Data diagnostics of the GreenDIGIT telemetry (exploratory analysis).

Writes ``eda_diagnostic_report.txt`` with five checks (loading and memory,
schema, per-column anomaly and completeness checks, rows per site) and two
figures: the correlation matrix of the numeric columns
(``01_full_correlation.png``) and the mean of a signal by hour of day per
site (``02_seasonality.png``).

The challenge-phase report in ``results/eda/`` was produced on the
event-level file ``summary_sites_raw.csv`` (7,483,973 events; available from
the challenge VRE, about 0.9 GB, not part of this repository). The script
also runs on the 15-minute summary in ``data/raw_metrics/``.

Usage (from the repository root):

    python challenge_code/eda/data_diagnostics.py --data /path/to/summary_sites_raw.csv
    python challenge_code/eda/data_diagnostics.py --data data/raw_metrics/summary_sites_15m.csv
"""

from __future__ import annotations

import argparse
import sys
import time
from datetime import datetime
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]

# =============================================================================
# CONFIG
# =============================================================================
CONFIG = {
    "data_path": REPO_ROOT / "data" / "raw_metrics" / "summary_sites_raw.csv",
    #   alternative: REPO_ROOT / "data" / "raw_metrics" / "summary_sites_15m.csv"
    "output_dir": REPO_ROOT / "runs" / "eda",
    "report_name": "eda_diagnostic_report.txt",
    "site_column": "site_id",
    "seasonality_signal": "energy_wh",       # "energy_wh" | "cfp_g" | any numeric column
    "peak_quantile": 0.95,                   # reported as "Peak Threshold" per numeric column
    "max_listed_categories": 10,             # list the categories of text columns up to this size
    "interval": ("se", 1.96),                # band of the seasonality plot: ("se", 1.96) ~ 95% CI | ("ci", 95) bootstrap (slow on 7.5M rows)
    "figure_dpi": 100,
}

# =============================================================================

import matplotlib  # noqa: E402

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import pandas as pd  # noqa: E402
import seaborn as sns  # noqa: E402


class Report:
    """Collects the lines of the report and echoes them to the console."""

    def __init__(self):
        self.lines = []

    def __call__(self, text: str = "") -> None:
        print(text)
        self.lines.append(text)

    def save(self, path: Path) -> None:
        path.write_text("\n".join(self.lines) + "\n", encoding="utf-8")


def find_time_column(columns) -> str:
    for column in columns:
        name = column.lower()
        if "timestamp" in name or "time" in name or "date" in name or "bucket" in name:
            return column
    return ""


def run(config: dict) -> None:
    started = time.time()
    data_path = Path(config["data_path"])
    out_dir = Path(config["output_dir"])
    out_dir.mkdir(parents=True, exist_ok=True)
    log = Report()
    log("=== DATA DIAGNOSTIC REPORT ===")
    log(f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    log(f"Target File: {data_path.name}")
    log("=" * 30)

    log("\n[1/5] Loading data and checking for structural errors...")
    if not data_path.is_file():
        log(f"-> ERROR: file not found: {data_path}")
        sys.exit(1)
    try:
        df = pd.read_csv(data_path, low_memory=False)
    except (pd.errors.ParserError, UnicodeDecodeError) as exc:
        log(f"-> ERROR: the file could not be parsed: {exc}")
        sys.exit(1)
    if df.empty:
        log("-> ERROR: the file has no rows")
        sys.exit(1)
    log(f"-> Successfully loaded {len(df):,} rows.")
    log(f"-> Memory Usage: {df.memory_usage(deep=True).sum() / 1024 ** 2:.2f} MB")

    log("\n[2/5] Discovering Data Schema...")
    numeric = df.select_dtypes(include="number").columns.tolist()
    text = [c for c in df.columns if c not in numeric]
    time_col = find_time_column(df.columns)
    log(f"-> Found {len(df.columns)} columns: {df.columns.tolist()}")
    log(f"-> Numeric Columns: {numeric}")
    log(f"-> Categorical/Text Columns: {text}")
    if time_col:
        log(f"-> Discovered primary time column: '{time_col}'")

    log("\n[3/5] Running Anomaly and Incomplete Data Checks...")
    for column in df.columns:
        values = df[column]
        log(f"\n--- Column: {column} ---")
        n_missing = int(values.isna().sum())
        if n_missing:
            log(f"  * Missing Values  : {n_missing:,} rows ({100 * n_missing / len(df):.2f}%)")
        else:
            log("  * No missing values.")
        if column in numeric:
            n_zero = int((values == 0).sum())
            if n_zero:
                log(f"  * Zero Values     : {n_zero:,} rows ({100 * n_zero / len(df):.2f}%)")
            n_negative = int((values < 0).sum())
            if n_negative:
                log(f"  * Negative Values : {n_negative:,} rows ({100 * n_negative / len(df):.2f}%)")
            log(f"  * Min: {values.min():.2f} | Mean: {values.mean():.2f} | Max: {values.max():.2f}")
            log(f"  * {100 * config['peak_quantile']:.0f}th Percentile (Peak Threshold): "
                f"{values.quantile(config['peak_quantile']):.2f}")
        else:
            uniques = values.dropna().unique()
            log(f"  * Unique Values: {len(uniques)}")
            if len(uniques) <= config["max_listed_categories"]:
                log(f"  * Categories: {list(uniques)}")

    log("\n[4/5] Checking Temporal Densities...")
    site_col = config["site_column"]
    if site_col in df.columns:
        log("-> Row counts per site:")
        for site, count in df[site_col].value_counts().sort_index().items():
            log(f"   * {site}: {count:,} records")
    else:
        log(f"-> column '{site_col}' not found, skipped")

    log("\n[5/5] Generating Visualizations...")
    plt.figure(figsize=(10, 8))
    sns.heatmap(df[numeric].corr(), annot=True, cmap="coolwarm", fmt=".2f")
    plt.title("Feature Correlation Matrix")
    plt.tight_layout()
    plt.savefig(out_dir / "01_full_correlation.png", dpi=config["figure_dpi"])
    plt.close()
    log("-> Saved Correlation Heatmap (01_full_correlation.png)")

    signal = config["seasonality_signal"]
    if time_col and signal in df.columns:
        hours = pd.to_datetime(df[time_col], utc=True).dt.hour
        plot_df = pd.DataFrame({"hour": hours, signal: df[signal]})
        hue = None
        if site_col in df.columns:
            plot_df[site_col] = df[site_col]
            hue = site_col
        plt.figure(figsize=(10, 6))
        sns.lineplot(data=plot_df, x="hour", y=signal, hue=hue, errorbar=tuple(config["interval"]))
        plt.title(f"Average {signal} by Hour of Day")
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(out_dir / "02_seasonality.png", dpi=config["figure_dpi"])
        plt.close()
        log("-> Saved Seasonality Plot (02_seasonality.png)")

    report_path = out_dir / config["report_name"]
    log(f"\n[SUCCESS] Diagnostic Complete in {time.time() - started:.2f} seconds!")
    log(f"Report saved to: {report_path}")
    log.save(report_path)


def main() -> None:
    parser = argparse.ArgumentParser(description="Diagnostics of a GreenDIGIT telemetry file")
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--output-dir", type=Path, default=None)
    args = parser.parse_args()
    config = dict(CONFIG)
    if args.data:
        config["data_path"] = args.data
    if args.output_dir:
        config["output_dir"] = args.output_dir
    run(config)


if __name__ == "__main__":
    main()
