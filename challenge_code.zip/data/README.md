# Data

Public data of the GreenDIGIT ECML-PKDD 2026 Discovery Challenge, as released
in the official challenge repository. The files are unchanged; the official
evaluators expect them in this place.

| File | Content |
| --- | --- |
| `raw_metrics/summary_sites_15m.csv` | EIMPS telemetry of three anonymised sites, one row per site, virtual organisation (VO) and 15-minute bucket: `bucket_15m, site_id, vo, activity, records, energy_wh, cfp_g, work, ncores` (28,662 rows, 2025-11-19 23:00 to 2026-03-12 17:00 UTC). Main input of Task A. |
| `raw_metrics/summary_sites_hourly.csv`, `summary_sites_daily.csv` | The same telemetry aggregated per hour and per day. |
| `raw_metrics/summary_sites_metadata.json` | Source, time range, totals and anonymisation rules of the export. |
| `task_a_series.csv` | Canonical Task A series (`series_id, bucket_15m, records, energy_wh, cfp_g`), one row per site and bucket (VO rows summed), written by `task-a prepare-data`. |
| `job_trace.csv` | Task B job trace: one aggregate job per site, VO and bucket (28,662 jobs), 15 CPU-minutes, 24 h of deadline slack, pinned to its site. |
| `site_config.json` | Task B site registry (capacity, PUE, dispatch latency). |
| `forecast_baseline.csv` | Offline signal source of the Task B simulator: the measured energy and carbon of every site bucket. |
| `prepare_data.py` | Rebuilds `job_trace.csv`, `site_config.json` and `forecast_baseline.csv` from `raw_metrics/summary_sites_15m.csv`. |

Official split: buckets at or before `2026-02-18T14:00:00+00:00` are training
data, later buckets the local test window (about 80/20). The final challenge
evaluation used later, private months.

## Event-level data

The challenge VRE also provides the granular event file
`summary_sites_raw.csv` (7,483,973 events, about 0.9 GB:
`event_id, event_start_timestamp, site_id, vo, activity, energy_wh, cfp_g,
work, ncores, pue, ci_g`). It is too large for this repository; place it in
`data/raw_metrics/` to run the diagnostics of `challenge_code/eda/` on it.
The Green-GRM loader accepts it as well and floors the events to 15-minute
buckets.
