| scheduler | final_score | pareto | declaration | deadline_penalty | delta_energy | delta_carbon | delta_makespan | jobs_dispatched | jobs | deadlines_met | decisions_immediate | decisions_deferred | decisions_no_forecast |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| greedy_carbon | 0.0125 | 0.0152 | 0.0023 | 0.0050 | 0.0207 | 0.0150 | 0.0099 | 5879 | 5938 | 5879 |  |  |  |
| green_grm | 0.1414 | 0.1125 | 0.0289 | 0.0000 | 0.1446 | 0.1928 | 0.0000 | 5938 | 5938 | 5938 | 3458.0000 | 2486.0000 | 0.0000 |
| green_grm_oracle | 0.5840 | 0.4711 | 0.1128 | 0.0000 | 0.6612 | 0.7522 | 0.0000 | 5938 | 5938 | 5938 | 2541.0000 | 3397.0000 | 0.0000 |
