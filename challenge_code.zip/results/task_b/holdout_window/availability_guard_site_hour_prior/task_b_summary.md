| scheduler | final_score | pareto | declaration | deadline_penalty | delta_energy | delta_carbon | delta_makespan | jobs_dispatched | jobs | deadlines_met | decisions_immediate | decisions_deferred | decisions_no_forecast |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| greedy_carbon | 0.0011 | 0.0000 | 0.0011 | 0.0000 | -0.0132 | 0.0070 | 0.0000 | 4158 | 4158 | 4158 |  |  |  |
| green_grm | 0.0746 | 0.0548 | 0.0198 | 0.0000 | 0.0325 | 0.1320 | 0.0000 | 4158 | 4158 | 4158 | 2283.0000 | 1877.0000 | 0.0000 |
| green_grm_oracle | 0.6048 | 0.4941 | 0.1107 | 0.0000 | 0.7447 | 0.7377 | 0.0000 | 4158 | 4158 | 4158 | 1625.0000 | 2533.0000 | 0.0000 |
