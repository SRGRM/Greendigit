| scheduler | final_score | pareto | declaration | deadline_penalty | delta_energy | delta_carbon | delta_makespan | jobs_dispatched | jobs | deadlines_met | decisions_immediate | decisions_deferred | decisions_no_forecast |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| greedy_carbon | 0.0011 | 0.0000 | 0.0011 | 0.0000 | -0.0132 | 0.0070 | 0.0000 | 4158 | 4158 | 4158 |  |  |  |
| green_grm | 0.0297 | 0.0127 | 0.0170 | 0.0000 | -0.0751 | 0.1132 | 0.0000 | 4158 | 4158 | 4158 | 497.0000 | 3667.0000 | 0.0000 |
| green_grm_oracle | 0.6398 | 0.5228 | 0.1170 | 0.0000 | 0.7883 | 0.7800 | 0.0000 | 4158 | 4158 | 4158 | 562.0000 | 3596.0000 | 0.0000 |
