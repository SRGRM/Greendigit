# Results

Outputs of the runs reported in the README at the root of the repository,
copied from `runs/`. The models, logs and hold-out predictions of the
individual search evaluations are not included to keep the repository small;
the commands of the main README recreate them.

| Folder | Produced by | Contents |
| --- | --- | --- |
| `green_grm/paper_protocol/` | `green_grm/run_green_grm.py --protocol paper` | configuration, run log, comparison of the five methods (`comparison.md`), search report, ranking and summary of every method, GRM estimator, Q table and visit counts, metrics of every selected configuration, final model with its three Task A files, figures |
| `green_grm/challenge_lab_protocol/` | `green_grm/run_green_grm.py --protocol challenge_lab` | the same files for the challenge-phase protocol |
| `task_b/test_window/` | `green_grm/run_task_b.py` | Task B scores of `greedy_carbon` and of the Green-GRM scheduler with forecasts and with measured signals (`task_b_summary.md`), dispatch log and per-job decisions of the Green-GRM scheduler, issued forecasts |
| `task_b/holdout_window/` | `green_grm/run_task_b.py --window holdout`, with `availability_guard` set to `"site_hour_prior"` and to `"none"` | the hold-out comparison on which the missing-telemetry guard was chosen |
| `challenge_code/model_lab/` | `challenge_code/task_a/model_lab.py` and `evaluate_lab_model.py` | report and metrics of Exp_21 and of the configuration of Table 2 in the challenge-phase pipeline |
| `challenge_code/random_forest_baseline/` | `challenge_code/task_a/random_forest_baseline.py` | official score of the first model of the challenge |
| `challenge_code/task_b/` | `challenge_code/task_b/run_scheduler.py` | challenge-phase Pareto scheduler on the smoke window and on the test window |
| `eda/challenge_phase/` | `challenge_code/eda/data_diagnostics.py` (challenge archive) | data diagnostics report and figures |

The reported runs used Python 3.13, NumPy 2.5.3, SciPy 1.18.1, pandas 3.0.5
and scikit-learn 1.9.1 on 2 CPU cores; new runs also record these versions
in their `run.log` and results file. Paths in the copied files are relative
to the repository root.
